import tensorly as tl
import numpy as np
from helpers import *

def haLRTC(corrupt_img, mask2D, a, b, K, img):
    print('HaLRTC:')
    p = 1e-6
    imSize = corrupt_img.shape
    ArrSize = np.array(imSize)
    ArrSize = np.append(ArrSize, 3)  # array of Mi / Yi
    Mi = np.zeros(ArrSize)
    Yi = np.zeros(ArrSize)

    for _ in range(K):
        print(_, end=" ")
        for i in range(ArrSize[3]):
            elem = tl.unfold(corrupt_img, i)
            elem = np.add(elem, tl.unfold(np.squeeze(Yi[:, :, :, i]), i) / p, out=elem, casting="unsafe")
            elem = shrinkage(elem, a[i] / p)
            Mi[:, :, :, i] = tl.fold(elem, i, imSize)

        corrupt_img = (1 / ArrSize[3]) * np.sum(Mi - Yi / p, ArrSize[3])
        corrupt_img[mask2D] = img[mask2D]

        for i in range(ArrSize[3]):
            Yi[:, :, :, i] = Yi[:, :, :, i] - p * (Mi[:, :, :, i] - corrupt_img)

        p = 1.2 * p

    return corrupt_img

dataframe = pd.read_csv('/home/raashika/Desktop/rasterMinerResultsImputation/f1.tsv')
img, pts_arr = df2np(dataframe)