import numpy as np
R = None
info = None
bpara = np.array([[3, 2, 6, 4], [3, 3, 6, 6], [-1, -1, -2, -2], [-1, -1, -2, -2], [65, 42, 50, 58]])
HR1 = None
HR2 = None
LR1 = None
pre_image = None
iband = None
count_temp = None
edge = None
N = None
epoch = None
tnot = None