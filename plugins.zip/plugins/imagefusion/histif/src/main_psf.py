from .pso_Trelea_vectorized_update import *
# import histif.src.global_vars as global_vars
from .global_vars import *
from .FFT import FFT



def check_missing_pixels(input_frame):
    """
        For checking if there exists any missing pixels
    """
    temp_frame = np.isnan(input_frame)
    missing_pixels = np.argwhere(temp_frame == True)

    if(len(missing_pixels) == 0):
        return False

    else:
        return True


def main_psf(coarse_img_t0=None, fine_img_t0=None, coarse_img_t1=None, params=None, iter=200, flag=0, neighbors=4, old_version=False):

    """
        The main function for performing fusion
    Returns:
        _numpy_array_: __The fused image or Predticed image__
    """

    if(flag == 0):

        fine1 = fine_img_t0
        coarse1 = coarse_img_t0
        coarse2 = coarse_img_t1


    elif(flag == 1):
        fine1 = fine_img_t0
        coarse1 = coarse_img_t0
        coarse2 = coarse_img_t1



    fn = np.size(fine1, 0)
    cn = np.size(coarse1, 0)

    edge = (cn - fn)/2
    xx = edge + 1
    yy = fn + edge
    N = yy - xx + 1

    limits = np.size(fine1, 2)
    print(limits)
    pre_para = None
    channel_image = []

    for iband in range(limits):
        count_temp = 1
        LR1 = fine1[:, :, iband]

        if(check_missing_pixels(LR1)):
            raise Exception("Missing pixels in the fine_t0 image!")
            # LR1 = fill_pixels(LR1, neighbors=neighbors)

        HR1 = coarse1[:, :, iband]
        # print(HR1)
        if(check_missing_pixels(HR1)):
            raise Exception("Missing pixels in the coarse_t0 image!")
            # HR1 = fill_pixels(HR1, neighbors=neighbors)

        HR2 = coarse2[:, :, iband]
        if(check_missing_pixels(HR2)):
            raise Exception("Missing pixels in the coarse_t1 image!")
            # HR2 = fill_pixels(HR2, neighbors=neighbors)

        LR1 = LR1.reshape(
            1, int(N*N))

        functname = 'optima'
        dims = 5
        varrange = params
        mvden = 2
        mv = []

        for i in range(dims):
            mv.append((varrange[i][1] - varrange[i][0]) / mvden)
        print(mv)
        minmax = 0
        plotfcn = 'goplotso'
        shw = 0
        ps = 30
        epoch = iter
        ac = [2.0, 2.0]
        Iwt = [0.9, 0.6]
        wt_end = 50
        errgrad = 1e-99
        errgraditer = 10
        errgoal = None
        modl = 0
        PSOseed = 0
        # print('near numpy')
        PSOseedValue = np.tile(np.array([0]), (ps, 1))

        psoparams = [shw, epoch, ps, ac[0], ac[1], Iwt[0], Iwt[1],
                     wt_end, errgrad, errgraditer, errgoal, modl, PSOseed]
        # print(psoparams)
        # try:
        pso_out, HR1_psf, tr, te = pso_Trelea_vectorized_update(
                      functname, dims, [mv, varrange, minmax, psoparams, plotfcn, PSOseedValue])
        # except:
        #     print('Error raised')
        #
        # if(pre_para is None):
        #     pre_para = pso_out.reshape(-1, 1)
        #
        # else:
        #     pre_para = np.column_stack((pre_para, pso_out))
        #
        # if(iband > 3):
        #     bpara = np.append(
        #         bpara, np.zeros((dims, 1)), axis=1)
        # print('near bpara')
    #     bpara[:, iband] = np.rint(
    #         pre_para[:dims, iband])
    #
    #     HR2_psf = FFT(bpara[:, iband], HR2)
    #     HR2_p = np.multiply(np.divide(HR2_psf, HR1_psf), LR1)
    #
    #     HR1_psf_cal = FFT(
    #         bpara[:, iband], HR1)
    #     predicted_HR1_p = np.multiply(
    #         np.divide(HR1_psf_cal, HR1_psf), LR1)
    #
    #     if(old_version is False):
    #         error = LR1 - predicted_HR1_p
    #
    #     else:
    #         error = 0
    #
    #     if(pre_image is None):
    #         pre_image = (
    #             HR2_p + error).reshape(int(N), int(N), 1)
    #     else:
    #         pre_image = np.dstack(
    #             (pre_image, (HR2_p + error).reshape(int(N), int(N), 1)))
    #
    #     channel_image.append(HR2_p.reshape(
    #         int(N), int(N)))
    #
    # # if(flag == False):
    # #     pre_lidar_dem = rxr.open_rasterio(fine_img_t0, masked=True)
    # #     sr = list(pre_lidar_dem.rio.resolution())[0]
    # # else:
    # #     sr = 2
    # # bpara[0:4, :] = np.multiply(bpara[0:4, :], sr)
    # # image_shape = list(pre_image.shape)
    # # return pre_image, np.array(channel_image),fine1Points
    # return np.array(channel_image)

# if __name__ == '__main__':
#     params = np.array([[0, 3], [0, 3], [-1, 1], [-1, 1], [35, 65]])
#     img_data_new, final_img = main_psf("coarse_t0.tif", "fine_t0.tif", "coarse_t1.tif", params, 1)
#     print(img_data_new)
#     print(img_data_new.shape)
#     plt.imshow(img_data_new, interpolation='nearest')
#     plt.axis('off')
#     cur_shape = list(img_data_new.shape)
#     print(final_img.shape)

#     dst_filename = 'test.tif'
#     x_pixels = (final_img[0]).shape[0]  # number of pixels in x
#     y_pixels = (final_img[0]).shape[1]  # number of pixels in y
#     driver = gdal.GetDriverByName('GTiff')
#     dataset = driver.Create(dst_filename,x_pixels, y_pixels, 4,gdal.GDT_Float32)
#     dataset.GetRasterBand(1).WriteArray(final_img[0])
#     dataset.GetRasterBand(2).WriteArray(final_img[1])
#     dataset.GetRasterBand(3).WriteArray(final_img[2])
#     dataset.GetRasterBand(4).WriteArray(final_img[3])
#     data0 = gdal.Open("coarse_t1.tif")
#     geotrans=data0.GetGeoTransform()
#     proj=data0.GetProjection()
#     dataset.SetGeoTransform(geotrans)
#     dataset.SetProjection(proj)
#     dataset.FlushCache()
#     dataset=None


#     # tifffile.imsave('test.tiff', img_data_new)
#     plt.show()
