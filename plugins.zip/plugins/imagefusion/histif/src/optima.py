from .FFT import FFT
from .global_vars import *

def optima(inputs):
    inputs = np.array(inputs)
    r = np.max(np.array(list(inputs.shape)))

    cost = []
    # print(r,inputs)
    for i in range(r):
        HR_p = FFT(inputs[i, :], HR1)
        # cost.append(np.sqrt(np.mean(np.power(HR_p - LR1, 2))))
    #
    # cost = np.array(cost).T
    # HR_pre = HR_p
    # return cost, HR_pre