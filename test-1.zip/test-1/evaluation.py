import numpy as np
from geotiff import GeoTiff
import pandas as pd
from sklearn.metrics import mean_squared_error
import math

class DataReader:

    def __init__(self, observed, predicted) -> None:
        self.observed = GeoTiff(observed)
        self.predicted = GeoTiff(predicted)

    def read_images(self):
        obs = np.array(self.observed.read())
        pred = np.array(self.predicted.read())
        return obs, pred

def find_cc(observed, predicted):
    """Finding Correlation Coefficient"""

    input_data = DataReader(observed, predicted)
    obs, pred = input_data.read_images()
    band_wise_data = []

    for band in range(obs.shape[2]):
        x_band = pd.Series(obs[:, :, band].flatten())
        y_band = pd.Series(pred[:, :, band].flatten())
        band_wise_data.append(x_band.corr(y_band))
        
    return band_wise_data

def find_rmse(observed, predicted):
    """Finding Root Mean Square Error"""

    input_data = DataReader(observed, predicted)
    obs, pred = input_data.read_images()
    band_wise_error = []

    for band in range(obs.shape[2]):
        band_wise_error.append(math.sqrt(mean_squared_error(obs[:, :, band], pred[:, :, band])))
        
    return band_wise_error

def find_mean_absolute_difference(observed, predicted):
    """Finding Mean Absolute Difference"""

    input_data = DataReader(observed, predicted)
    obs, pred = input_data.read_images()
    band_wise_error = []

    for band in range(obs.shape[2]):
        band_wise_error.append(np.mean(abs(obs[:, :, band] - pred[:, :, band])))
        
    return band_wise_error

def display_result(param_name, values):

    bands = ["Blue", "Green", "Red", "NIR"]
    for i in range(len(bands)):
        print("The {} for the {} is {}".format(param_name, bands[i], values[i]))

actual_file = 'fine_t1.tif'
new_predicted_file = 'new-output.tif'
old_predicted_file = 'old-output.tif'
starfm_predicted_file = 'starfm-output.tif'

print("Results with new code : ")
print("====================================================")
print()
display_result("Correlation Coefficient", find_cc(actual_file, new_predicted_file))
display_result("Root Mean Square Error (RMSE)", find_rmse(actual_file, new_predicted_file))
display_result("Mean Absolute Error", find_mean_absolute_difference(actual_file, new_predicted_file))
print()
print("====================================================")

print("Results with old code : ")
print("====================================================")
print()
display_result("Correlation Coefficient", find_cc(actual_file, old_predicted_file))
display_result("Root Mean Square Error (RMSE)", find_rmse(actual_file, old_predicted_file))
display_result("Mean Absolute Error", find_mean_absolute_difference(actual_file, old_predicted_file))
print()
print("====================================================")

print("Results with STARFM : ")
print("====================================================")
print()
display_result("Correlation Coefficient", find_cc(actual_file, starfm_predicted_file))
display_result("Root Mean Square Error (RMSE)", find_rmse(actual_file, starfm_predicted_file))
display_result("Mean Absolute Error", find_mean_absolute_difference(actual_file, starfm_predicted_file))
print()
print("====================================================")
