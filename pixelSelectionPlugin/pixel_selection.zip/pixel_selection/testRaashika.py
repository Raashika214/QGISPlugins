import csv
import matplotlib.pyplot as plt
import numpy as np

# def readFromFile():
#     loadFileName = "/home/raashika/qgisPluginTest.csv"
#     xPoint = []
#     yPoint = []
#     xyNote = []
#     bands = []
#     print("IN FUNCTION")
#     with open(loadFileName, 'r', newline='', encoding='utf-8') as loadfile:
#         reader = csv.reader(loadfile, delimiter=',')
#         for row in reader:
#             xPoint.append(float(row[0]))
#             yPoint.append(float(row[1]))
#             bands.append((row[4:]))
#             xyNote.append(row[2])
#         print(xPoint)
#         print(yPoint)
#         print(bands[0])
#         band = []
#         a =[]
#         for band in bands:
#             for i in band:
#                 print(float(i))
#
#
#
#
#         # bands =  [float(i) for i in bands[0]]
#         # print(type(bands[0][1]))
#         fig = plt.figure(figsize=(10,7))
#         # plt.boxplot(bands[1])
#     # for i in range(len(xPoint)):
#     #     pointIndex = i
#     #     comboUpdate()

# a  = readFromFile()
import pandas as pd
df =  pd.read_csv("/home/raashika/qgistest.csv",sep= ',',header=None)
print(df.iloc[:,4])
print(df.shape[1])
print(df.index)
# print(df)

df = df.iloc[:,3:-1]
df = df.T.reset_index(drop=True).T

print(df)
df.plot(kind = 'box')

# for i in range(2,df.shape[1]):
#     df.boxplot([i])
    # plt.boxplot(df.iloc[:, i])

# plt.boxplot(df.iloc[:, 3],showmeans=True)
# plt.boxplot(df.iloc[:, 4])
# plt.boxplot(df.iloc[:, 5])
plt.xticks(np.arange(0,9))
plt.show()
# print(df.shape,len(df))