from time import time
# from geotiff import GeoTiff as gt
from osgeo import gdal
import pylab
# Importing our image completion algorithms and helper functions
from .algos import *

class ImputationAlgo:
    def __init__(self, image, outputFileName, tensor_rank_estimate=12):
        '''
            Imputes missing data in a given tif file.
            tensor_rank_estimate: Estimate for tensor rank.
        '''
        try:
            # self.input_file = pd.read_csv(input_file, sep='\t')
            # self.img, self.pts_arr = df2np(self.input_file)
            self.img = image

        except:
            raise Exception("Invalid input")

        self.imSize = self.img.shape
        self.tensor_rank_estimate = tensor_rank_estimate
        self.speed = "fast"
        self.auxilary_arr_for_cmtf = None
        self.current_mask = None  # m1
        self._corrupt_img = None  # must be unmodifiable
        self.imputedArray = None
        self.outputFileName = outputFileName

        self.is_imputation_done = False
        self.fixed_img_np = None  # fixed image after imputation
        self.algo_runtime = []  # list to keep track of runtime for each algo
        # self.geotrans = self.dataset.GetGeoTransform()
        # self.projection = self.dataset.GetProjection()

    def get_corrupt_img(self):
        return self._corrupt_img

    def set_corrupt_img(self, value):
        self._corrupt_img = value

    def generate_mask(self, threshold_value=0.1):
        '''
            def: Generates a mask for the image.
            @args threshold_value: The threshold value for the mask,
            depends completely on the dataframe
            We detect a mask by identifying outlier pixels and dead pixels
            [TODO] Idea: manual masking to get accurate mask?? discuss with sir.
        '''
        if self.get_corrupt_img() is None:
            self.set_corrupt_img(self.img)
        self.current_mask = masker(self.get_corrupt_img(), threshold_value)

        return self.current_mask

    def synthetic_mask(self, fraction_to_keep=0.7):
        '''
            def: Generates a synthetic mask for the image.
        '''
        corrupt_img_output, perfect_mask = randomDelete(self.img, fraction_to_keep)
        self.set_corrupt_img(corrupt_img_output)
        self.current_mask = perfect_mask

        return self.current_mask
    


    def impute(self, algo, output_file, speed="fast", tol=1e-4):
        '''
            def: Imputes missing data in a given dataframe.
            @args speed: "slow"/"fast"(default), speed of the algorithm
            @args visualize: bool (default False) to determine whether to
                             visualize the output.
        '''
        # siLRTC Implementation
        if algo == 'siLRTC':
            if self.speed == "slow":
                sil = 60
            else:
                sil = 0
            img_orig = self.get_corrupt_img().copy()
            # Defining constants
            a = abs(np.random.rand(self.imSize[-1], 1))
            a = a / np.sum(a)
            b = abs(np.random.rand(self.imSize[-1], 1)) / 200
            self.algo_runtime = []
            self.algo_runtime.append(time())
            self.imputedArray = siLRTC(self.get_corrupt_img(), self.current_mask, a, b, sil, img_orig)
            print('')
            self.algo_runtime.append(time())


        elif algo == 'haLRTC':

            if self.speed == "slow":
                hal = 60
            else:
                hal = 0
            img_orig = self.get_corrupt_img().copy()
            # Defining constants
            a = abs(np.random.rand(self.imSize[-1], 1))
            a = a / np.sum(a)
            b = abs(np.random.rand(self.imSize[-1], 1)) / 200
            self.algo_runtime = []
            self.algo_runtime.append(time())
            self.imputedArray = haLRTC(self.get_corrupt_img(), self.current_mask, a, b, hal, img_orig)
            print('')
            self.algo_runtime.append(time())

        elif algo == 'faLRTC':
            if self.speed == "slow":
                fal = 60
            else:
                fal = 0
            img_orig = self.get_corrupt_img().copy()
            # Defining constants
            a = abs(np.random.rand(self.imSize[-1], 1))
            a = a / np.sum(a)
            b = abs(np.random.rand(self.imSize[-1], 1)) / 200
            self.algo_runtime = []
            self.algo_runtime.append(time())
            self.imputedArray = haLRTC(self.get_corrupt_img(), self.current_mask, a, b, fal, img_orig)
            print('')
            self.algo_runtime.append(time())
            print(self.algo_runtime[1] - self.algo_runtime[0])

        elif algo == 'CMTF':
            if self.speed == "slow":
                cmtf_itr = 400
            else:
                cmtf_itr = 200

            img_orig = self.get_corrupt_img().copy()
            # Defining constants
            print('processing CMTF1')
            self.auxilary_arr_for_cmtf = self.get_corrupt_img()[:, :, 0]
            self.algo_runtime = []
            self.algo_runtime.append(time())
            print('processing CMTF2')
            _, self.imputedArray = cmtf(self.get_corrupt_img(),
                                        [self.auxilary_arr_for_cmtf, self.auxilary_arr_for_cmtf],
                                        [0, 1], self.tensor_rank_estimate, self.current_mask, tol=tol, maxiter=cmtf_itr)
            print('CMTF Done')
            self.algo_runtime.append(time())


        elif algo == 'CP_ALS':
            if self.speed == "slow":
                cp = 400
            else:
                cp = 200

            img_orig = self.get_corrupt_img().copy()
            # Defining constants
            a = abs(np.random.rand(self.imSize[-1], 1))
            a = a / np.sum(a)
            b = abs(np.random.rand(self.imSize[-1], 1)) / 200
            self.algo_runtime = []
            self.algo_runtime.append(time())
            P, self.imputedArray = cp_als(self.get_corrupt_img(), self.tensor_rank_estimate, self.current_mask, tol= 0.0004,
                                          maxiter=cp)
            print('Done CP ALS')
            self.algo_runtime.append(time())

        #
        # print('Runtime : ', self.algo_runtime)
        # self.is_imputation_done = True
        #
        # # store it as tsv File
        # # result_df = pd.DataFrame(np.reshape(self.imputedArray,(self.imputedArray.shape[0]* self.imputedArray.shape[1], self.imputedArray.shape[2])))
        # # result_df.insert(0,self.pts_arr)
        # # result_df.to_csv(self.outputFileName,sep='\t',index=False)
        # print(P,self.imputedArray)
        return self.imputedArray

        # # writing output as geotif file
        # driver = gdal.GetDriverByName('GTiff')
        # output_file = driver.Create(output_file, self.imputedArray.shape[0], self.imputedArray.shape[1],
        #                             self.imputedArray.shape[2],
        #                             gdal.GDT_Float32)
        # for band_range in range(self.imputedArray.shape[2]):
        #     output_file.GetRasterBand(band_range + 1).WriteArray(self.imputedArray[:, :, band_range])
        # output_file.SetGeoTransform(self.geotrans)
        # output_file.SetProjection(self.projection)
        # output_file.FlushCache()
        # output_file = None
        # self.imputedArray  = self.imputedArray.reshape(self.imputedArray.shape[0]* self.imputedArray.shape[1],-1)
        # print(self.imputedArray.shape)
        # result_df = pd.DataFrame(self.imputedArray)
        # x_points = self.pts_arr.apply(get_x_point)
        # y_points = self.pts_arr.apply(get_y_point)
        # result_df.insert(0,'x',x_points)
        # result_df.insert(1,'y',y_points)
        # result_df.to_csv(output_file,sep='\t',index=None)
        # print("Imputation completed successfully!")
